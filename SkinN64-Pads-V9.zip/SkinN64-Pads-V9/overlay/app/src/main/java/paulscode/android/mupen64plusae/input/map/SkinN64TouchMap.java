package paulscode.android.mupen64plusae.input.map;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.DisplayMetrics;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import paulscode.android.mupen64plusae.input.AbstractController;
import paulscode.android.mupen64plusae.profile.Profile;

/** M64Plus FZ touch map backed directly by the original SkinN64 artwork. */
public final class SkinN64TouchMap extends VisibleTouchMap {
    public static final String MENU="menu", JEUX="jeux", CHEAT="cheat", QUIT="quit", FF="ff", MANETTE="manette";
    private final Context context;
    private final Map<String, RectF> sourceRects = new HashMap<>();
    private final Map<String, Bitmap> sprites = new HashMap<>();
    private final Matrix matrix = new Matrix();
    private String folder = "portrait";
    private Bitmap background;
    private float sourceW, sourceH, factor, offsetX, offsetY;
    private int viewW, viewH;
    private RectF screen = new RectF();
    private boolean analogEnabled = true;
    private boolean nativeMode;
    private String nativeSkinDir;
    private Profile nativeProfile;
    private boolean nativeAnimated;
    private float nativeScale;
    private int nativeAlpha;
    private Bitmap nativeReturnButton;
    private int variant;

    public SkinN64TouchMap(Context context) {
        super(context.getResources());
        this.context = context.getApplicationContext();
        variant = context.getSharedPreferences("skin_n64", Context.MODE_PRIVATE).getInt("variante_paysage", 0);
        // V9 ne propose plus le pad natif : uniquement les deux pads SkinN64.
        if (variant < 0 || variant > 1) variant = 0;
        try { nativeReturnButton=bitmap("skinn64/paysage/manette_0.png"); } catch(Exception ignored) { }
    }

    @Override public void load(Context ignored, String skinDir, Profile profile, boolean animated, float scale, int alpha) {
        nativeSkinDir=skinDir; nativeProfile=profile; nativeAnimated=animated; nativeScale=scale; nativeAlpha=alpha;
        chooseFolder(viewW, viewH);
    }

    private Bitmap bitmap(String path) throws Exception {
        try (InputStream in = context.getAssets().open(path)) { return BitmapFactory.decodeStream(in); }
    }

    private void chooseFolder(int w, int h) {
        // Le moteur M64Plus FZ reste intact, mais son habillage tactile d'origine
        // n'est plus affiché. Le bouton manette alterne seulement les pads SkinN64.
        nativeMode=false;
        String next = (w > h && w > 0) ? (variant == 1 ? "paysage2" : "paysage") : "portrait";
        if (next.equals(folder) && background != null) { compute(w, h); return; }
        folder = next; sourceRects.clear(); sprites.clear();
        try {
            background = bitmap("skinn64/" + folder + "/fond.png");
            sourceW = background.getWidth(); sourceH = background.getHeight();
            String raw;
            try (InputStream in = context.getAssets().open("skinn64/" + folder + "/positions.json")) {
                byte[] data = new byte[in.available()]; int n=in.read(data); raw=new String(data,0,n,"UTF-8");
            }
            JSONArray a = new JSONObject(raw).getJSONArray("elements");
            for (int i=0;i<a.length();i++) {
                JSONObject e=a.getJSONObject(i); String id=e.getString("id");
                sourceRects.put(id,new RectF((float)e.getDouble("x"),(float)e.getDouble("y"),
                        (float)(e.getDouble("x")+e.getDouble("w")),(float)(e.getDouble("y")+e.getDouble("h"))));
                try { sprites.put(id, bitmap("skinn64/"+folder+"/"+id+"_0.png")); } catch(Exception ignored) { }
            }
            if (folder.equals("portrait")) screen=new RectF(65,179,786,917);
            else if (folder.equals("paysage")) screen=new RectF(380,156,1464,651);
            else if (folder.equals("paysage2")) screen=new RectF(316,15,1528,835);
            else screen=new RectF(0,0,sourceW,sourceH);
        } catch(Exception e) { background=null; }
        compute(w,h);
    }

    private void compute(int w,int h) {
        viewW=w; viewH=h; if(background==null || w<=0 || h<=0)return;
        factor=Math.max(w/sourceW,h/sourceH); // cover: no deformation, edges alone may be cropped
        offsetX=(w-sourceW*factor)/2f; offsetY=(h-sourceH*factor)/2f;
        matrix.reset(); matrix.postScale(factor,factor); matrix.postTranslate(offsetX,offsetY);
    }

    @Override public void resize(int w,int h, DisplayMetrics metrics) { chooseFolder(w,h); }
    @Override public void resize(int w,int h) { chooseFolder(w,h); }

    private RectF mapped(String id) {
        RectF src=sourceRects.get(id); if(src==null)return new RectF();
        RectF out=new RectF(src); matrix.mapRect(out); return out;
    }
    public Rect getGameRect() { if(nativeMode)return new Rect(0,0,viewW,viewH); RectF r=new RectF(screen); matrix.mapRect(r); return new Rect(Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)); }

    @Override public void drawButtons(Canvas c) {
        if(nativeMode){
            super.drawButtons(c);
            if(nativeReturnButton!=null)c.drawBitmap(nativeReturnButton,null,nativeReturnRect(),null);
            return;
        }
        if(background==null)return;
        int save=c.save(); Rect game=getGameRect();
        if(android.os.Build.VERSION.SDK_INT>=26)c.clipOutRect(game); else c.clipRect(game, android.graphics.Region.Op.DIFFERENCE);
        c.drawBitmap(background,matrix,null);
        for(Map.Entry<String,Bitmap> e:sprites.entrySet()) {
            RectF r=mapped(e.getKey()); c.drawBitmap(e.getValue(),null,r,null);
        }
        c.restoreToCount(save);
    }
    @Override public void drawAnalog(Canvas c) { if(nativeMode)super.drawAnalog(c); }
    @Override public void drawAutoHold(Canvas c) { if(nativeMode)super.drawAutoHold(c); }
    @Override public boolean updateAnalog(float x,float y) { return nativeMode && super.updateAnalog(x,y); }
    @Override public boolean updateAutoHold(boolean p,int i) { return nativeMode && super.updateAutoHold(p,i); }

    private boolean hit(String id,int x,int y){ return mapped(id).contains(x,y); }
    private RectF nativeReturnRect(){float d=context.getResources().getDisplayMetrics().density;return new RectF(12*d,12*d,76*d,76*d);}
    public String functionAt(float x,float y){
        if(nativeMode)return nativeReturnRect().contains(x,y)?MANETTE:null;
        for(String id:new String[]{MENU,JEUX,CHEAT,QUIT,FF,MANETTE})if(hit(id,(int)x,(int)y))return id;
        return null;
    }
    public void cycleVariant(){ variant=(variant+1)%2; context.getSharedPreferences("skin_n64",Context.MODE_PRIVATE).edit().putInt("variante_paysage",variant).apply(); folder=""; chooseFolder(viewW,viewH); }

    @Override public int getButtonPress(int x,int y) {
        if(nativeMode)return super.getButtonPress(x,y);
        if(hit("A",x,y))return AbstractController.BTN_A;
        if(hit("B",x,y))return AbstractController.BTN_B;
        if(hit("start",x,y))return AbstractController.START;
        if(hit("L",x,y))return AbstractController.BTN_L;
        if(hit("R",x,y))return AbstractController.BTN_R;
        if(hit("Z",x,y))return AbstractController.BTN_Z;
        if(hit("cHaut",x,y))return AbstractController.CPD_U;
        if(hit("cBas",x,y))return AbstractController.CPD_D;
        if(hit("cGauche",x,y))return AbstractController.CPD_L;
        if(hit("cDroite",x,y))return AbstractController.CPD_R;
        RectF d=mapped("croix"); if(d.contains(x,y)){
            float dx=(x-d.centerX())/(d.width()/2),dy=(y-d.centerY())/(d.height()/2);
            if(Math.abs(dx)>.22f && Math.abs(dy)>.22f)return dx>0?(dy>0?DPD_RD:DPD_RU):(dy>0?DPD_LD:DPD_LU);
            if(Math.abs(dx)>Math.abs(dy))return dx>0?AbstractController.DPD_R:AbstractController.DPD_L;
            return dy>0?AbstractController.DPD_D:AbstractController.DPD_U;
        }
        return UNMAPPED;
    }
    @Override public Rect getButtonFrame(String name){ if(nativeMode)return super.getButtonFrame(name);RectF r=mapped(name); return new Rect(Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)); }
    @Override public Rect getAnalogFrame(){ if(nativeMode)return super.getAnalogFrame();RectF r=mapped("stick"); return new Rect(Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)); }
    @Override public Point getAnalogDisplacement(int x,int y){ if(nativeMode)return super.getAnalogDisplacement(x,y);Rect r=getAnalogFrame(); return analogEnabled?new Point(x-r.centerX(),y-r.centerY()):new Point(); }
    @Override public Point getAnalogDisplacementOriginal(int x,int y){ return nativeMode?super.getAnalogDisplacementOriginal(x,y):getAnalogDisplacement(x,y); }
    @Override public void updateAnalogPosition(int x,int y){ if(nativeMode)super.updateAnalogPosition(x,y); }
    @Override public void resetAnalogPosition(){ if(nativeMode)super.resetAnalogPosition(); }
    @Override public float getAnalogStrength(float displacement){ if(nativeMode)return super.getAnalogStrength(displacement);Rect r=getAnalogFrame(); float radius=Math.max(1,Math.min(r.width(),r.height())*.42f); return Math.max(0,Math.min(1,displacement/radius)); }
    @Override public boolean isInCaptureRange(Point p){ if(nativeMode)return super.isInCaptureRange(p);Rect r=getAnalogFrame(); float radius=Math.max(r.width(),r.height())*.75f; return analogEnabled && p.x*p.x+p.y*p.y<=radius*radius; }
    @Override public void setAnalogEnabled(boolean enabled){ analogEnabled=enabled;if(nativeMode)super.setAnalogEnabled(enabled); }
}
